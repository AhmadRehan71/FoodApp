package com.mabnets.foodapp.model;

public class Food {

    int id;
    String name;
    String imageURL;
    String price;
    String location;

    public Food(int id, String name, String imageURL, String price, String location) {
        this.id = id;
        this.name = name;
        this.imageURL = imageURL;
        this.price = price;
        this.location = location;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
